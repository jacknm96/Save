Exercise 1: Alphabetize a File
This program reads from a file and alphabetizes the list of words. Launch the executable. It will
ask you which file you would like to read from to sort. Make sure the file is in the same folder
as the program. After sorting, it will output the results to output.txt.