Exercise 1: Sum of Array
Launch the executable. The program will ask you how long you would like your array. It creates an array
of that size and fills it with random numbers. It will ask you what the max number should be. It will
then print out the array, followed by the sum.

Exercise 2: Sorting an Array
Launch the executable. The program will ask you how long you would like your array. It creates an array
of that size and fills it with random numbers. It will ask you what the max number should be. It will
then print out the array, followed by the sorted array.