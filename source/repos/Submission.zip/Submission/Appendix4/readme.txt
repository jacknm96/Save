Exercise 1: Greetings
Launch the executable. The program will ask for a name, and then if it's a doctor or not ('y' or 'n' required).
It will then introduce itself.

Exercise 2: Adventure Game
Launch the executable. No input required, it will give the output shown in the instructions.