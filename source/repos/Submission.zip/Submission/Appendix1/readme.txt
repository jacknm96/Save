Exercise 1: Adding Two Numbers
Launch the executable. The program will ask you to input 2 numbers. These numbers must be floats. 
If they are not, it will ask you to input a float. It will then print out the total, cast to an int.

Exercise 2: Fibonacci
Launch the executable. The program will ask you how many digits of Fibonacci you will like. Input
an int. It will then print out the number of digits of Fibonacci you asked for.

Exercise 3: FizzBuzz
Launch the executable. The program will ask you what number you would like to count to. It will
count to that number, replacing numbers with "Fizz" and "Buzz" as necessary.